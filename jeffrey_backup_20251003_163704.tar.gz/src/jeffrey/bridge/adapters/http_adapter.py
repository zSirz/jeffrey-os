#!/usr/bin/env python3
"""
HTTP Adapter - Connexion sécurisée au web
Correction GPT : Health check local
"""

import logging
from typing import Any, Dict, Optional

import aiohttp

# Import propre depuis le parent
from ..base import BaseBridgeAdapter

logger = logging.getLogger(__name__)


class HttpAdapter(BaseBridgeAdapter):
    """
    Adapter HTTP avec cache et retry
    Health check sans dépendance réseau
    """

    def __init__(self):
        super().__init__("http")
        self._session: Optional[aiohttp.ClientSession] = None
        self._cache: Dict[str, Any] = {}
        self._cache_ttl = 300  # 5 minutes

    async def initialize(self) -> None:
        """Initialise la session HTTP"""
        await super().initialize()

        timeout = aiohttp.ClientTimeout(total=30, connect=5)

        self._session = aiohttp.ClientSession(
            timeout=timeout,
            headers={
                "User-Agent": "Jeffrey-OS/1.0",
                "Accept": "application/json, text/html, */*",
            },
        )

        logger.info("HTTP adapter initialized")

    async def health(self) -> bool:
        """
        CORRECTION GPT : Health check local
        Vérifie que la session est ouverte, pas de requête réseau
        """
        return self._session is not None and not self._session.closed

    async def shutdown(self) -> None:
        """Ferme la session HTTP"""
        if self._session and not self._session.closed:
            await self._session.close()
            self._session = None

        await super().shutdown()

    async def get(
        self,
        url: str,
        params: Optional[Dict[str, Any]] = None,
        headers: Optional[Dict[str, str]] = None,
        use_cache: bool = True,
    ) -> Dict[str, Any]:
        """Effectue une requête GET avec cache"""
        if not self._session or self._session.closed:
            raise RuntimeError("HTTP adapter not initialized")

        # Cache check
        cache_key = f"{url}:{str(params)}"
        if use_cache and cache_key in self._cache:
            logger.debug(f"Cache hit for {url}")
            return self._cache[cache_key]

        try:
            async with self._session.get(url, params=params, headers=headers) as response:
                data = {
                    "status": response.status,
                    "headers": dict(response.headers),
                    "url": str(response.url),
                }

                content_type = response.headers.get("Content-Type", "")

                if "application/json" in content_type:
                    data["data"] = await response.json()
                elif "text/" in content_type:
                    data["data"] = await response.text()
                else:
                    data["data"] = await response.read()

                # Cache if successful
                if use_cache and response.status == 200:
                    self._cache[cache_key] = data

                    # Clean old cache entries
                    if len(self._cache) > 100:
                        # Remove oldest entries
                        for key in list(self._cache.keys())[:20]:
                            del self._cache[key]

                return data

        except aiohttp.ClientError as e:
            logger.error(f"HTTP request failed: {e}")
            return {"status": 0, "error": str(e), "url": url}

    async def post(
        self,
        url: str,
        data: Optional[Any] = None,
        json: Optional[Dict[str, Any]] = None,
        headers: Optional[Dict[str, str]] = None,
    ) -> Dict[str, Any]:
        """Effectue une requête POST"""
        if not self._session or self._session.closed:
            raise RuntimeError("HTTP adapter not initialized")

        try:
            async with self._session.post(url, data=data, json=json, headers=headers) as response:
                result = {
                    "status": response.status,
                    "headers": dict(response.headers),
                    "url": str(response.url),
                }

                content_type = response.headers.get("Content-Type", "")
                if "application/json" in content_type:
                    result["data"] = await response.json()
                else:
                    result["data"] = await response.text()

                return result

        except aiohttp.ClientError as e:
            logger.error(f"HTTP POST failed: {e}")
            return {"status": 0, "error": str(e), "url": url}

    def clear_cache(self) -> None:
        """Vide le cache"""
        self._cache.clear()
        logger.info("HTTP cache cleared")

    def get_cache_stats(self) -> Dict[str, Any]:
        """Retourne les stats du cache"""
        return {"entries": len(self._cache), "keys": list(self._cache.keys())[:10]}  # Top 10 keys
