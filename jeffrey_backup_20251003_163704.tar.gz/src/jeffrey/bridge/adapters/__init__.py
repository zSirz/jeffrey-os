"""Jeffrey Bridge Adapters for external APIs."""

# Temporairement désactivé pour les tests headless
# from .elevenlabs_adapter import ElevenLabsAdapter
# from .provider_api_adapter import ProviderAPIAdapter
# from .weather_adapter import WeatherAdapter

# __all__ = ["WeatherAdapter", "ProviderAPIAdapter", "ElevenLabsAdapter"]

from .http_adapter import HttpAdapter

__all__ = ["HttpAdapter"]
