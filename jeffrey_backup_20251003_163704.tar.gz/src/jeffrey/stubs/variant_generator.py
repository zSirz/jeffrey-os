class VariantGenerator:
    def generate_variants(self, *args, **kwargs):
        return []
