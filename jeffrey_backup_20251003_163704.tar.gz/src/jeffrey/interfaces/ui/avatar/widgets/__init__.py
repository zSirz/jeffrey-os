"""
Package contenant les widgets personnalisés pour l'interface utilisateur.
"""