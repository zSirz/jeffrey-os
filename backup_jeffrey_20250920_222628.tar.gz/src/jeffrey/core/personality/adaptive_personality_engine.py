#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
adaptive_personality_engine.py - Module de gestion de la personnalité adaptative de Jeffrey.
Ce moteur ajuste dynamiquement la personnalité en fonction des expériences émotionnelles, interactions et apprentissages continus.
"""

from collections import defaultdict
from datetime import datetime


class AdaptivePersonalityEngine:
    def __init__(self):
        self.personality_profile = defaultdict(
            lambda: {"baseline": 0.5, "variation": [], "last_update": None}
        )

        def register_emotional_event(self, trait: str, impact_score: float):
        """
        Enregistre un événement émotionnel affectant un trait de personnalité.

        Args:
            trait (str): Le trait affecté (ex: 'curiosité', 'confiance').
            impact_score (float): L'effet mesuré de l'événement (de -1.0 à +1.0).
        """
                if trait not in self.personality_profile:
            self.personality_profile[trait] = {
                "baseline": 0.5,
                "variation": [],
                "last_update": None,
            }

        self.personality_profile[trait]["variation"].append(
            {"timestamp": datetime.now().isoformat(), "impact": impact_score}
        )
        self.personality_profile[trait]["last_update"] = datetime.now().isoformat()

                    def get_current_profile(self):
        """
        Calcule l’état actuel des traits de personnalité.

        Returns:
            dict: Un dictionnaire avec les traits et leur score actuel.
        """
        profile = {}
                            for trait, data in self.personality_profile.items():
            base = data["baseline"]
            variations = [
                v["impact"] for v in data["variation"][-20:]
            ]  # On limite à 20 derniers événements
            variation_score = sum(variations) / len(variations) if variations else 0
            score = max(0.0, min(1.0, base + variation_score))
            profile[trait] = round(score, 3)
                                return profile

                                def reset_trait(self, trait: str):
        """
        Réinitialise un trait à son état de base.

        Args:
            trait (str): Le trait à réinitialiser.
        """
                                        if trait in self.personality_profile:
            self.personality_profile[trait]["variation"] = []
            self.personality_profile[trait]["last_update"] = datetime.now().isoformat()

                                            def export_profile(self):
        """
        Exporte le profil complet avec historique.

        Returns:
            dict: Le profil complet incluant baseline, variations et timestamps.
        """
                                                    return dict(self.personality_profile)
