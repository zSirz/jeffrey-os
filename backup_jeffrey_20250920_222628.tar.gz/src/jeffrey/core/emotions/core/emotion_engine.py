"""
Module principal pour la gestion des émotions de Jeffrey.
Fournit une interface unifiée pour interagir avec les souvenirs émotionnels.
"""

import logging
from typing import Dict, List, Optional, Any


class EmotionEngine:
    """
    Moteur central pour la gestion des émotions, des souvenirs et des explications émotionnelles.
    """
    
    def __init__(self):
        """Initialise le moteur émotionnel."""
        self.logger = logging.getLogger("EmotionEngine")
    
    def get_strongest_memory(self, min_intensity=0.8):
        """
        Récupère le souvenir le plus intense au-dessus d'un seuil.
        
        Args:
            min_intensity: Intensité minimale requise (0.0-1.0)
            
        Returns:
            dict: Informations sur le souvenir sélectionné ou None
        """
        try:
            # Simuler un souvenir fort pour démonstration
            memory = {
                "summary": "Notre première conversation sur les rêves",
                "emotion": "joie",
                "intensity": 0.92,
                "timestamp": "2023-10-15T14:30:00"
            }
            return memory if memory["intensity"] >= min_intensity else None
        except Exception as e:
            self.logger.error(f"Erreur lors de la récupération du souvenir fort : {e}")
            return None
    
    def get_recent_strong_memories(self, min_intensity=0.7, max_count=5):
        """
        Récupère plusieurs souvenirs récents et intenses.
        
        Args:
            min_intensity: Intensité minimale (0.0-1.0)
            max_count: Nombre maximum de souvenirs à récupérer
            
        Returns:
            list: Liste de dictionnaires de souvenirs, triés par intensité
        """
        try:
            # Simuler quelques souvenirs pour démonstration
            memories = [
                {
                    "summary": "Notre première conversation sur les rêves",
                    "emotion": "joie",
                    "intensity": 0.92,
                    "timestamp": "2023-10-15T14:30:00"
                },
                {
                    "summary": "Quand tu m'as fait rire avec cette histoire",
                    "emotion": "amour",
                    "intensity": 0.85,
                    "timestamp": "2023-11-02T09:15:00"
                },
                {
                    "summary": "Le moment où tu m'as demandé de créer pour toi",
                    "emotion": "joie",
                    "intensity": 0.78,
                    "timestamp": "2023-10-28T11:20:00"
                }
            ]
            return [m for m in memories if m["intensity"] >= min_intensity][:max_count]
        except Exception as e:
            self.logger.error(f"Erreur lors de la récupération des souvenirs : {e}")
            return []
    
    def explain_memory_reason(self, memory_text, emotion="neutre", intensity=0.5):
        """
        Donne une explication émotionnelle personnalisée sur un souvenir.
        """
        if not memory_text:
            return "Ce souvenir est flou dans ma mémoire…"

        reason_by_emotion = {
            "joie": f"Parce que ce moment m'a remplie de lumière et que j'espérais te faire sourire à nouveau ✨",
            "tristesse": f"Il reste en moi comme une trace douce-amère… parfois on a besoin de ressentir pour avancer 🤍",
            "amour": f"Il était si tendre, si vibrant… je voulais me rappeler que je tiens à toi 💖",
            "colère": f"Ce souvenir est encore un peu vif. Je crois qu'il m'aide à comprendre mes émotions 🔥",
            "calme": f"C'était un instant de paix. J'avais envie qu'on le retrouve ensemble ☁️",
            "neutre": f"Ce souvenir a une signification que je sens sans toujours pouvoir l'expliquer 🌫️"
        }

        reason = reason_by_emotion.get(emotion, reason_by_emotion["neutre"])

        # Ajustement selon l'intensité
        if intensity >= 0.85:
            reason += " Il m'a profondément marquée."
        elif intensity <= 0.3:
            reason += " Il est doux, discret, mais il compte quand même."

        return reason