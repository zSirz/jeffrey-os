#!/usr/bin/env python3
"""
Jeffrey OS Phase 0.7 + 0.8 Integration
Complete integration between human feedback system and meta-learning system
"""

import asyncio
import logging
import json
import time
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, List, Any, Optional, Tuple
from dataclasses import dataclass
import sqlite3

# Phase 0.7 imports
from core.feedback.proposal_manager import ProposalManager
from core.feedback.human_interface import HumanInterface
from storage.proposal_store import ProposalStore
from provenance.chain_tracker import ChainTracker
from core.feedback.feedback_analyzer import FeedbackAnalyzer
from core.feedback.models import Proposal, Decision, VerdictType, ProposalType, RiskLevel

# Phase 0.8 imports
from core.learning.meta_learner import MetaLearner
from core.learning.theory_of_mind import TheoryOfMind
from core.learning.feature_extractor import AdvancedFeatureExtractor
from core.learning.model_trainer import ModelTrainer
from core.learning.causal_predictor import CausalPredictor
from core.learning.dream_suggester import DreamSuggester
from core.learning.explainer import Explainer


@dataclass
class IntegrationConfig:
    """Configuration for the integrated system"""
    # Phase 0.7 config
    proposal_store_path: str = "data/proposals.db"
    provenance_store_path: str = "data/provenance.db"
    feedback_store_path: str = "data/feedback.db"
    
    # Phase 0.8 config
    learning_data_path: str = "data/learning"
    model_store_path: str = "data/models"
    
    # Integration config
    auto_learning_enabled: bool = True
    suggestion_threshold: float = 0.6
    explanation_enabled: bool = True
    multi_language_support: bool = True
    supported_languages: List[str] = None
    
    # Performance config
    batch_size: int = 10
    learning_frequency_hours: int = 24
    drift_detection_enabled: bool = True
    
    def __post_init__(self):
        if self.supported_languages is None:
            self.supported_languages = ['en', 'fr', 'es', 'de', 'it', 'pt']


class MetaLearningIntegration:
    """
    Main integration class that combines Phase 0.7 and Phase 0.8
    """
    
    def __init__(self, config: IntegrationConfig = None):
        self.config = config or IntegrationConfig()
        
        # Initialize Phase 0.7 components
        self.proposal_store = ProposalStore(self.config.proposal_store_path)
        self.proposal_manager = ProposalManager(self.proposal_store)
        self.human_interface = HumanInterface(self.proposal_manager)
        self.chain_tracker = ChainTracker(self.config.provenance_store_path)
        self.feedback_analyzer = FeedbackAnalyzer(self.config.feedback_store_path)
        
        # Initialize Phase 0.8 components
        self.meta_learner = MetaLearner(self.config.learning_data_path)
        self.theory_of_mind = TheoryOfMind()
        self.feature_extractor = AdvancedFeatureExtractor()
        self.model_trainer = ModelTrainer(self.config.model_store_path)
        self.causal_predictor = CausalPredictor()
        self.dream_suggester = DreamSuggester(self.config.learning_data_path)
        self.explainer = Explainer(self.config.learning_data_path)
        
        # Integration state
        self.learning_enabled = False
        self.last_learning_time = None
        self.integration_stats = {
            'total_predictions': 0,
            'successful_predictions': 0,
            'suggestions_provided': 0,
            'explanations_generated': 0,
            'learning_cycles': 0
        }
        
        # Initialize integration database
        self.integration_db_path = Path(self.config.learning_data_path) / "integration.db"
        self._init_integration_database()
        
        # Setup logging
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )
        self.logger = logging.getLogger(__name__)
        
        self.logger.info("Jeffrey OS Meta-Learning Integration initialized")
    
    def _init_integration_database(self):
        """Initialize integration tracking database"""
        Path(self.config.learning_data_path).mkdir(parents=True, exist_ok=True)
        
        with sqlite3.connect(self.integration_db_path) as conn:
            cursor = conn.cursor()
            
            # Integration events table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS integration_events (
                    id TEXT PRIMARY KEY,
                    event_type TEXT,
                    proposal_id TEXT,
                    phase TEXT,
                    details TEXT,
                    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)
            
            # Prediction tracking table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS prediction_tracking (
                    id TEXT PRIMARY KEY,
                    proposal_id TEXT,
                    predicted_verdict TEXT,
                    actual_verdict TEXT,
                    confidence REAL,
                    suggestion_provided BOOLEAN,
                    explanation_generated BOOLEAN,
                    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)
            
            # Learning cycles table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS learning_cycles (
                    id TEXT PRIMARY KEY,
                    cycle_start TIMESTAMP,
                    cycle_end TIMESTAMP,
                    proposals_processed INTEGER,
                    accuracy_improvement REAL,
                    drift_detected BOOLEAN,
                    retrain_triggered BOOLEAN
                )
            """)
            
            conn.commit()
    
    async def initialize_learning_system(self):
        """Initialize the learning system with historical data"""
        self.logger.info("Initializing learning system with historical data...")
        
        try:
            # Extract historical data from Phase 0.7
            historical_data = await self._extract_historical_data()
            
            if len(historical_data['proposals']) > 0:
                # Train meta-learner
                self.logger.info(f"Training meta-learner with {len(historical_data['proposals'])} proposals")
                training_results = self.meta_learner.train(
                    historical_data['proposals'],
                    historical_data['decisions'],
                    historical_data['rationales'],
                    historical_data['languages']
                )
                
                # Train dream suggester
                self.logger.info("Training dream suggester...")
                self.dream_suggester.learn_from_history(
                    historical_data['proposals'],
                    historical_data['decisions'],
                    historical_data['rationales'],
                    historical_data['languages']
                )
                
                # Train causal predictor
                self.logger.info("Training causal predictor...")
                features = []
                for i, proposal in enumerate(historical_data['proposals']):
                    feature_vector = self.feature_extractor.extract_features(
                        proposal, 
                        historical_data['rationales'][i], 
                        historical_data['languages'][i]
                    )
                    features.append(feature_vector)
                
                self.causal_predictor.train(features, historical_data['decisions'])
                
                self.learning_enabled = True
                self.last_learning_time = datetime.now()
                self.integration_stats['learning_cycles'] += 1
                
                self.logger.info(f"Learning system initialized successfully. Training accuracy: {training_results.get('classifier_accuracy', 0):.2f}")
                
                # Record learning cycle
                self._record_learning_cycle(
                    len(historical_data['proposals']),
                    training_results.get('classifier_accuracy', 0)
                )
                
            else:
                self.logger.warning("No historical data available. Learning system will start from scratch.")
                
        except Exception as e:
            self.logger.error(f"Failed to initialize learning system: {e}")
            raise
    
    async def _extract_historical_data(self) -> Dict[str, List]:
        """Extract historical data from Phase 0.7 storage"""
        proposals = []
        decisions = []
        rationales = []
        languages = []
        
        # Get all completed proposals from storage
        completed_proposals = await self.proposal_store.get_proposals_by_status('completed')
        
        for proposal in completed_proposals:
            # Get decision for this proposal
            decision = await self.proposal_store.get_decision_by_proposal_id(proposal.id)
            if decision and decision.verdict != VerdictType.DEFER:
                # Get rationale from feedback analyzer
                rationale = await self.feedback_analyzer.get_rationale_for_decision(decision.id)
                
                # Detect language (simple heuristic for now)
                language = self._detect_language(rationale)
                
                proposals.append(proposal)
                decisions.append(decision)
                rationales.append(rationale or "No rationale provided")
                languages.append(language)
        
        return {
            'proposals': proposals,
            'decisions': decisions,
            'rationales': rationales,
            'languages': languages
        }
    
    def _detect_language(self, text: str) -> str:
        """Simple language detection heuristic"""
        if not text:
            return 'en'
        
        # Simple keyword-based detection
        french_keywords = ['le', 'la', 'et', 'est', 'dans', 'avec', 'pour', 'que', 'une', 'sur']
        spanish_keywords = ['el', 'la', 'y', 'es', 'en', 'con', 'para', 'que', 'una', 'por']
        german_keywords = ['der', 'die', 'und', 'ist', 'in', 'mit', 'für', 'dass', 'eine', 'auf']
        italian_keywords = ['il', 'la', 'e', 'è', 'in', 'con', 'per', 'che', 'una', 'su']
        portuguese_keywords = ['o', 'a', 'e', 'é', 'em', 'com', 'para', 'que', 'uma', 'de']
        
        text_lower = text.lower()
        words = text_lower.split()
        
        if len(words) < 3:
            return 'en'
        
        # Count language indicators
        french_count = sum(1 for word in words if word in french_keywords)
        spanish_count = sum(1 for word in words if word in spanish_keywords)
        german_count = sum(1 for word in words if word in german_keywords)
        italian_count = sum(1 for word in words if word in italian_keywords)
        portuguese_count = sum(1 for word in words if word in portuguese_keywords)
        
        # Return language with highest count
        counts = {
            'fr': french_count,
            'es': spanish_count,
            'de': german_count,
            'it': italian_count,
            'pt': portuguese_count
        }
        
        max_lang = max(counts, key=counts.get)
        return max_lang if counts[max_lang] > 0 else 'en'
    
    async def enhanced_proposal_processing(self, proposal: Proposal, 
                                         context: Dict[str, Any] = None) -> Dict[str, Any]:
        """
        Enhanced proposal processing with meta-learning integration
        """
        self.logger.info(f"Processing proposal {proposal.id} with meta-learning enhancement")
        
        result = {
            'proposal_id': proposal.id,
            'prediction': None,
            'suggestions': [],
            'explanation': None,
            'confidence': 0.0,
            'recommendation': 'proceed_with_human_review'
        }
        
        try:
            if self.learning_enabled:
                # Step 1: Make prediction with understanding
                prediction = self.meta_learner.predict_with_understanding(proposal, context)
                result['prediction'] = prediction
                result['confidence'] = prediction.confidence
                
                # Step 2: Generate suggestions if confidence is low or rejection likely
                rejection_prob = prediction.verdict_probability.get('reject', 0)
                if prediction.confidence < self.config.suggestion_threshold or rejection_prob > 0.5:
                    suggestions = self.dream_suggester.suggest_reformulation(proposal)
                    result['suggestions'] = suggestions
                    self.integration_stats['suggestions_provided'] += 1
                    
                    # Enhanced proposal text
                    if suggestions:
                        enhanced_text = self.dream_suggester.reformulation_engine.enhance_proposal_text(
                            proposal, suggestions
                        )
                        result['enhanced_proposal'] = enhanced_text
                
                # Step 3: Generate explanation if enabled
                if self.config.explanation_enabled:
                    explanation = self.explainer.explain_prediction(
                        proposal, 
                        prediction.causal_factors, 
                        prediction.verdict_probability
                    )
                    result['explanation'] = explanation
                    self.integration_stats['explanations_generated'] += 1
                
                # Step 4: Generate recommendation
                result['recommendation'] = self._generate_recommendation(prediction, result['suggestions'])
                
                # Step 5: Record prediction for later accuracy tracking
                self._record_prediction(proposal.id, prediction, result['suggestions'], result['explanation'])
                
                self.integration_stats['total_predictions'] += 1
                
            else:
                result['recommendation'] = 'learning_not_ready'
                self.logger.warning("Learning system not ready. Falling back to human review.")
            
        except Exception as e:
            self.logger.error(f"Error in enhanced proposal processing: {e}")
            result['error'] = str(e)
            result['recommendation'] = 'error_fallback_to_human'
        
        # Record integration event
        self._record_integration_event('proposal_processed', proposal.id, 'integration', result)
        
        return result
    
    def _generate_recommendation(self, prediction, suggestions) -> str:
        """Generate recommendation based on prediction and suggestions"""
        max_verdict = max(prediction.verdict_probability, key=prediction.verdict_probability.get)
        max_prob = prediction.verdict_probability[max_verdict]
        
        if prediction.confidence > 0.9 and max_prob > 0.8:
            if max_verdict == 'accept':
                return 'auto_accept_high_confidence'
            elif max_verdict == 'reject':
                return 'auto_reject_high_confidence'
        
        if suggestions and len(suggestions) > 0:
            return 'suggest_improvements_before_review'
        
        if prediction.confidence < 0.5:
            return 'request_additional_information'
        
        return 'proceed_with_human_review'
    
    def _record_prediction(self, proposal_id: str, prediction, suggestions, explanation):
        """Record prediction for accuracy tracking"""
        with sqlite3.connect(self.integration_db_path) as conn:
            cursor = conn.cursor()
            
            prediction_id = f"pred_{datetime.now().strftime('%Y%m%d_%H%M%S')}_{proposal_id}"
            max_verdict = max(prediction.verdict_probability, key=prediction.verdict_probability.get)
            
            cursor.execute("""
                INSERT INTO prediction_tracking (
                    id, proposal_id, predicted_verdict, confidence, 
                    suggestion_provided, explanation_generated
                ) VALUES (?, ?, ?, ?, ?, ?)
            """, (
                prediction_id,
                proposal_id,
                max_verdict,
                prediction.confidence,
                len(suggestions) > 0 if suggestions else False,
                explanation is not None
            ))
            
            conn.commit()
    
    def _record_integration_event(self, event_type: str, proposal_id: str, phase: str, details: Dict):
        """Record integration event"""
        with sqlite3.connect(self.integration_db_path) as conn:
            cursor = conn.cursor()
            
            event_id = f"event_{datetime.now().strftime('%Y%m%d_%H%M%S')}_{proposal_id}"
            
            cursor.execute("""
                INSERT INTO integration_events (
                    id, event_type, proposal_id, phase, details
                ) VALUES (?, ?, ?, ?, ?)
            """, (
                event_id,
                event_type,
                proposal_id,
                phase,
                json.dumps(details, default=str)
            ))
            
            conn.commit()
    
    def _record_learning_cycle(self, proposals_processed: int, accuracy: float):
        """Record learning cycle"""
        with sqlite3.connect(self.integration_db_path) as conn:
            cursor = conn.cursor()
            
            cycle_id = f"cycle_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
            
            cursor.execute("""
                INSERT INTO learning_cycles (
                    id, cycle_start, cycle_end, proposals_processed, accuracy_improvement
                ) VALUES (?, ?, ?, ?, ?)
            """, (
                cycle_id,
                self.last_learning_time,
                datetime.now(),
                proposals_processed,
                accuracy
            ))
            
            conn.commit()
    
    async def update_learning_with_feedback(self, proposal_id: str, actual_decision: Decision, 
                                          rationale: str, language: str = 'en'):
        """Update learning system with human feedback"""
        self.logger.info(f"Updating learning system with feedback for proposal {proposal_id}")
        
        try:
            # Get the original proposal
            proposal = await self.proposal_store.get_proposal_by_id(proposal_id)
            if not proposal:
                self.logger.warning(f"Proposal {proposal_id} not found")
                return
            
            # Update prediction tracking with actual outcome
            self._update_prediction_accuracy(proposal_id, actual_decision.verdict.value)
            
            # Check if we should trigger retraining
            if self._should_trigger_retraining():
                await self._trigger_incremental_learning()
            
            # Update dream suggester with feedback
            if hasattr(self, 'dream_suggester'):
                # This could be enhanced to track suggestion effectiveness
                pass
            
            # Record feedback event
            self._record_integration_event('feedback_received', proposal_id, 'learning_update', {
                'actual_verdict': actual_decision.verdict.value,
                'rationale': rationale,
                'language': language
            })
            
        except Exception as e:
            self.logger.error(f"Error updating learning with feedback: {e}")
    
    def _update_prediction_accuracy(self, proposal_id: str, actual_verdict: str):
        """Update prediction accuracy tracking"""
        with sqlite3.connect(self.integration_db_path) as conn:
            cursor = conn.cursor()
            
            cursor.execute("""
                UPDATE prediction_tracking 
                SET actual_verdict = ?, 
                    correct_prediction = CASE 
                        WHEN predicted_verdict = ? THEN 1 
                        ELSE 0 
                    END
                WHERE proposal_id = ?
            """, (actual_verdict, actual_verdict, proposal_id))
            
            conn.commit()
    
    def _should_trigger_retraining(self) -> bool:
        """Determine if retraining should be triggered"""
        if not self.config.drift_detection_enabled:
            return False
        
        # Check if enough time has passed
        if self.last_learning_time:
            time_since_last = datetime.now() - self.last_learning_time
            if time_since_last.total_seconds() / 3600 < self.config.learning_frequency_hours:
                return False
        
        # Check prediction accuracy
        with sqlite3.connect(self.integration_db_path) as conn:
            cursor = conn.cursor()
            
            cursor.execute("""
                SELECT 
                    COUNT(*) as total,
                    SUM(CASE WHEN correct_prediction = 1 THEN 1 ELSE 0 END) as correct
                FROM prediction_tracking
                WHERE actual_verdict IS NOT NULL
                AND timestamp > datetime('now', '-7 days')
            """)
            
            result = cursor.fetchone()
            
            if result and result[0] > 10:  # Minimum predictions needed
                accuracy = result[1] / result[0]
                if accuracy < 0.7:  # Accuracy threshold
                    return True
        
        return False
    
    async def _trigger_incremental_learning(self):
        """Trigger incremental learning with recent data"""
        self.logger.info("Triggering incremental learning...")
        
        try:
            # Get recent data
            recent_data = await self._get_recent_training_data()
            
            if len(recent_data['proposals']) > 5:  # Minimum data for incremental learning
                # Perform incremental update
                training_results = self.meta_learner.train(
                    recent_data['proposals'],
                    recent_data['decisions'],
                    recent_data['rationales'],
                    recent_data['languages']
                )
                
                # Update dream suggester
                self.dream_suggester.learn_from_history(
                    recent_data['proposals'],
                    recent_data['decisions'],
                    recent_data['rationales'],
                    recent_data['languages']
                )
                
                self.last_learning_time = datetime.now()
                self.integration_stats['learning_cycles'] += 1
                
                self.logger.info(f"Incremental learning completed. New accuracy: {training_results.get('classifier_accuracy', 0):.2f}")
                
                # Record learning cycle
                self._record_learning_cycle(
                    len(recent_data['proposals']),
                    training_results.get('classifier_accuracy', 0)
                )
                
        except Exception as e:
            self.logger.error(f"Error in incremental learning: {e}")
    
    async def _get_recent_training_data(self) -> Dict[str, List]:
        """Get recent training data for incremental learning"""
        proposals = []
        decisions = []
        rationales = []
        languages = []
        
        # Get proposals from last 7 days with decisions
        cutoff_date = datetime.now() - timedelta(days=7)
        recent_proposals = await self.proposal_store.get_proposals_since(cutoff_date)
        
        for proposal in recent_proposals:
            decision = await self.proposal_store.get_decision_by_proposal_id(proposal.id)
            if decision and decision.verdict != VerdictType.DEFER:
                rationale = await self.feedback_analyzer.get_rationale_for_decision(decision.id)
                language = self._detect_language(rationale)
                
                proposals.append(proposal)
                decisions.append(decision)
                rationales.append(rationale or "No rationale provided")
                languages.append(language)
        
        return {
            'proposals': proposals,
            'decisions': decisions,
            'rationales': rationales,
            'languages': languages
        }
    
    async def get_integration_statistics(self) -> Dict[str, Any]:
        """Get comprehensive integration statistics"""
        stats = self.integration_stats.copy()
        
        # Add accuracy metrics
        with sqlite3.connect(self.integration_db_path) as conn:
            cursor = conn.cursor()
            
            # Overall accuracy
            cursor.execute("""
                SELECT 
                    COUNT(*) as total,
                    SUM(CASE WHEN correct_prediction = 1 THEN 1 ELSE 0 END) as correct,
                    AVG(confidence) as avg_confidence
                FROM prediction_tracking
                WHERE actual_verdict IS NOT NULL
            """)
            
            result = cursor.fetchone()
            if result and result[0] > 0:
                stats['overall_accuracy'] = result[1] / result[0]
                stats['average_confidence'] = result[2]
                stats['total_predictions_with_feedback'] = result[0]
            
            # Recent accuracy (last 7 days)
            cursor.execute("""
                SELECT 
                    COUNT(*) as total,
                    SUM(CASE WHEN correct_prediction = 1 THEN 1 ELSE 0 END) as correct
                FROM prediction_tracking
                WHERE actual_verdict IS NOT NULL
                AND timestamp > datetime('now', '-7 days')
            """)
            
            result = cursor.fetchone()
            if result and result[0] > 0:
                stats['recent_accuracy'] = result[1] / result[0]
                stats['recent_predictions'] = result[0]
            
            # Learning cycles
            cursor.execute("""
                SELECT COUNT(*) FROM learning_cycles
            """)
            stats['total_learning_cycles'] = cursor.fetchone()[0]
        
        # Add component statistics
        stats['meta_learner_stats'] = self.meta_learner.get_performance_metrics()
        stats['dream_suggester_stats'] = self.dream_suggester.get_suggestion_effectiveness()
        stats['explainer_stats'] = self.explainer.get_explanation_statistics()
        
        return stats
    
    async def run_integration_healthcheck(self) -> Dict[str, Any]:
        """Run comprehensive health check on integration"""
        health_check = {
            'overall_health': 'healthy',
            'components': {},
            'issues': [],
            'recommendations': []
        }
        
        try:
            # Check Phase 0.7 components
            health_check['components']['proposal_store'] = 'healthy' if self.proposal_store else 'error'
            health_check['components']['human_interface'] = 'healthy' if self.human_interface else 'error'
            health_check['components']['chain_tracker'] = 'healthy' if self.chain_tracker else 'error'
            
            # Check Phase 0.8 components
            health_check['components']['meta_learner'] = 'healthy' if self.learning_enabled else 'not_ready'
            health_check['components']['dream_suggester'] = 'healthy' if self.dream_suggester else 'error'
            health_check['components']['explainer'] = 'healthy' if self.explainer else 'error'
            
            # Check database connectivity
            try:
                with sqlite3.connect(self.integration_db_path) as conn:
                    conn.execute("SELECT 1")
                health_check['components']['integration_db'] = 'healthy'
            except Exception as e:
                health_check['components']['integration_db'] = 'error'
                health_check['issues'].append(f"Integration database error: {e}")
            
            # Check recent activity
            stats = await self.get_integration_statistics()
            if stats.get('recent_predictions', 0) == 0:
                health_check['issues'].append("No recent predictions")
                health_check['recommendations'].append("Increase proposal processing activity")
            
            if stats.get('recent_accuracy', 0) < 0.7:
                health_check['issues'].append("Recent accuracy below threshold")
                health_check['recommendations'].append("Consider retraining models")
            
            # Overall health assessment
            error_count = sum(1 for status in health_check['components'].values() if status == 'error')
            if error_count > 0:
                health_check['overall_health'] = 'error'
            elif len(health_check['issues']) > 2:
                health_check['overall_health'] = 'warning'
            
        except Exception as e:
            health_check['overall_health'] = 'error'
            health_check['issues'].append(f"Health check error: {e}")
        
        return health_check
    
    async def shutdown(self):
        """Gracefully shutdown the integration"""
        self.logger.info("Shutting down Jeffrey OS Meta-Learning Integration...")
        
        try:
            # Save current state
            if self.learning_enabled:
                model_path = Path(self.config.model_store_path) / "final_model.pkl"
                self.meta_learner.export_model(str(model_path))
            
            # Close database connections
            # (SQLite connections are automatically closed)
            
            # Record shutdown event
            self._record_integration_event('system_shutdown', 'system', 'integration', {
                'stats': self.integration_stats,
                'learning_enabled': self.learning_enabled
            })
            
            self.logger.info("Integration shutdown complete")
            
        except Exception as e:
            self.logger.error(f"Error during shutdown: {e}")


async def main():
    """Main function to demonstrate integration"""
    # Create configuration
    config = IntegrationConfig(
        proposal_store_path="data/proposals.db",
        learning_data_path="data/learning",
        auto_learning_enabled=True,
        suggestion_threshold=0.6,
        explanation_enabled=True
    )
    
    # Initialize integration
    integration = MetaLearningIntegration(config)
    
    try:
        # Initialize learning system
        await integration.initialize_learning_system()
        
        # Run health check
        health = await integration.run_integration_healthcheck()
        print(f"Integration Health: {health['overall_health']}")
        
        # Get statistics
        stats = await integration.get_integration_statistics()
        print(f"Integration Statistics: {stats}")
        
        # Simulate proposal processing
        from feedback.models import EventSource
        test_proposal = Proposal(
            id="integration_test_001",
            type=ProposalType.FEATURE,
            description="Add new user authentication system with multi-factor authentication",
            detailed_plan="Implement OAuth2 with SAML integration and biometric authentication support",
            sources=[EventSource(id="req_001", name="Security Requirements", url="http://internal.com/sec-req")],
            impact_score=0.8,
            risk_level=RiskLevel.MEDIUM
        )
        
        # Process proposal with enhancement
        result = await integration.enhanced_proposal_processing(test_proposal)
        print(f"Enhanced Processing Result: {result['recommendation']}")
        
        if result['prediction']:
            print(f"Prediction: {result['prediction'].verdict_probability}")
            print(f"Confidence: {result['prediction'].confidence:.2f}")
        
        if result['suggestions']:
            print(f"Suggestions: {len(result['suggestions'])} provided")
        
        if result['explanation']:
            print(f"Explanation: {result['explanation'].natural_language_summary}")
        
    except Exception as e:
        print(f"Integration error: {e}")
        
    finally:
        # Shutdown
        await integration.shutdown()


if __name__ == "__main__":
    asyncio.run(main())