"""
ElevenLabs API Client for Jeffrey V3.

Clean, async wrapper around ElevenLabs API with proper error handling,
streaming support, and modern Python patterns.
"""

import asyncio
import logging
from typing import Optional, Dict, Any, AsyncIterator, List
from dataclasses import dataclass
from pathlib import Path
import aiohttp
import json

logger = logging.getLogger(__name__)


class ElevenLabsError(Exception):
    """Base exception for ElevenLabs API errors."""
    pass


class VoiceNotFoundError(ElevenLabsError):
    """Raised when a requested voice is not found."""
    pass


class APIQuotaError(ElevenLabsError):
    """Raised when API quota is exceeded."""
    pass


@dataclass
class VoiceSettings:
    """Voice configuration settings for ElevenLabs synthesis."""
    stability: float = 0.5
    similarity_boost: float = 0.75
    style: float = 0.0
    use_speaker_boost: bool = True
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for API requests."""
        return {
            "stability": self.stability,
            "similarity_boost": self.similarity_boost,
            "style": self.style,
            "use_speaker_boost": self.use_speaker_boost
        }
    
    @classmethod
    def from_emotion(cls, emotion: str) -> "VoiceSettings":
        """Create voice settings based on emotion."""
        emotion_presets = {
            "neutral": cls(stability=0.5, similarity_boost=0.75),
            "happy": cls(stability=0.3, similarity_boost=0.85, style=0.2),
            "sad": cls(stability=0.7, similarity_boost=0.65, style=-0.1),
            "excited": cls(stability=0.2, similarity_boost=0.9, style=0.3),
            "calm": cls(stability=0.8, similarity_boost=0.7, style=-0.2),
            "angry": cls(stability=0.4, similarity_boost=0.8, style=0.1),
            "whisper": cls(stability=0.9, similarity_boost=0.6, style=-0.3),
        }
        
        return emotion_presets.get(emotion.lower(), cls())


@dataclass
class Voice:
    """Voice information from ElevenLabs API."""
    voice_id: str
    name: str
    category: str = "premade"
    description: Optional[str] = None
    preview_url: Optional[str] = None
    available_for_tiers: List[str] = None
    
    def __post_init__(self):
        if self.available_for_tiers is None:
            self.available_for_tiers = []


class ElevenLabsClient:
    """
    Async client for ElevenLabs API.
    
    Provides clean interface for text-to-speech generation with streaming
    support, voice management, and proper error handling.
    """
    
    BASE_URL = "https://api.elevenlabs.io/v1"
    MAX_TEXT_LENGTH = 5000  # ElevenLabs limit
    
    def __init__(self, api_key: str, timeout: float = 30.0):
        """
        Initialize ElevenLabs client.
        
        Args:
            api_key: ElevenLabs API key
            timeout: Request timeout in seconds
        """
        self.api_key = api_key
        self.timeout = aiohttp.ClientTimeout(total=timeout)
        self.session: Optional[aiohttp.ClientSession] = None
        self._voices_cache: Optional[List[Voice]] = None
        self._cache_ttl = 3600  # 1 hour cache for voices
        self._cache_timestamp = 0
        
    async def __aenter__(self):
        """Async context manager entry."""
        await self._ensure_session()
        return self
        
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit."""
        await self.close()
    
    async def _ensure_session(self):
        """Ensure aiohttp session is created."""
        if self.session is None or self.session.closed:
            headers = {
                "xi-api-key": self.api_key,
                "Content-Type": "application/json",
                "User-Agent": "Jeffrey-V3/1.0.0"
            }
            self.session = aiohttp.ClientSession(
                headers=headers,
                timeout=self.timeout
            )
    
    async def close(self):
        """Close the aiohttp session."""
        if self.session and not self.session.closed:
            await self.session.close()
    
    def _validate_text(self, text: str) -> str:
        """Validate and clean text for synthesis."""
        if not text or not text.strip():
            raise ValueError("Text cannot be empty")
        
        # Clean text
        text = text.strip()
        
        # Check length
        if len(text) > self.MAX_TEXT_LENGTH:
            logger.warning(f"Text truncated from {len(text)} to {self.MAX_TEXT_LENGTH} characters")
            text = text[:self.MAX_TEXT_LENGTH]
        
        return text
    
    async def generate_speech_stream(
        self,
        text: str,
        voice_id: str,
        voice_settings: Optional[VoiceSettings] = None,
        model_id: str = "eleven_monolingual_v1"
    ) -> AsyncIterator[bytes]:
        """
        Generate speech from text with streaming output.
        
        Args:
            text: Text to synthesize
            voice_id: ElevenLabs voice ID
            voice_settings: Voice configuration
            model_id: Model to use for synthesis
            
        Yields:
            Audio chunks as bytes
            
        Raises:
            ElevenLabsError: If API request fails
            ValueError: If text is invalid
        """
        await self._ensure_session()
        
        text = self._validate_text(text)
        
        if voice_settings is None:
            voice_settings = VoiceSettings()
        
        payload = {
            "text": text,
            "model_id": model_id,
            "voice_settings": voice_settings.to_dict()
        }
        
        url = f"{self.BASE_URL}/text-to-speech/{voice_id}/stream"
        
        try:
            async with self.session.post(url, json=payload) as response:
                await self._handle_response_errors(response)
                
                # Stream audio chunks
                async for chunk in response.content.iter_chunked(8192):
                    if chunk:
                        yield chunk
                        
        except aiohttp.ClientError as e:
            logger.error(f"ElevenLabs API request failed: {e}")
            raise ElevenLabsError(f"API request failed: {e}")
    
    async def generate_speech(
        self,
        text: str,
        voice_id: str,
        voice_settings: Optional[VoiceSettings] = None,
        model_id: str = "eleven_monolingual_v1"
    ) -> bytes:
        """
        Generate speech from text, returning complete audio data.
        
        Args:
            text: Text to synthesize
            voice_id: ElevenLabs voice ID
            voice_settings: Voice configuration
            model_id: Model to use for synthesis
            
        Returns:
            Complete audio data as bytes
            
        Raises:
            ElevenLabsError: If API request fails
        """
        audio_chunks = []
        
        async for chunk in self.generate_speech_stream(
            text, voice_id, voice_settings, model_id
        ):
            audio_chunks.append(chunk)
        
        return b''.join(audio_chunks)
    
    async def get_voices(self, force_refresh: bool = False) -> List[Voice]:
        """
        Get available voices from ElevenLabs API.
        
        Args:
            force_refresh: Force refresh of cached voices
            
        Returns:
            List of available voices
            
        Raises:
            ElevenLabsError: If API request fails
        """
        await self._ensure_session()
        
        # Check cache
        if (not force_refresh and 
            self._voices_cache and 
            (asyncio.get_event_loop().time() - self._cache_timestamp) < self._cache_ttl):
            return self._voices_cache
        
        url = f"{self.BASE_URL}/voices"
        
        try:
            async with self.session.get(url) as response:
                await self._handle_response_errors(response)
                data = await response.json()
                
                voices = []
                for voice_data in data.get("voices", []):
                    voice = Voice(
                        voice_id=voice_data["voice_id"],
                        name=voice_data["name"],
                        category=voice_data.get("category", "premade"),
                        description=voice_data.get("description"),
                        preview_url=voice_data.get("preview_url"),
                        available_for_tiers=voice_data.get("available_for_tiers", [])
                    )
                    voices.append(voice)
                
                # Update cache
                self._voices_cache = voices
                self._cache_timestamp = asyncio.get_event_loop().time()
                
                logger.info(f"Retrieved {len(voices)} voices from ElevenLabs")
                return voices
                
        except aiohttp.ClientError as e:
            logger.error(f"Failed to get voices: {e}")
            raise ElevenLabsError(f"Failed to get voices: {e}")
    
    async def get_voice_by_name(self, name: str) -> Optional[Voice]:
        """
        Get voice by name.
        
        Args:
            name: Voice name to search for
            
        Returns:
            Voice object if found, None otherwise
        """
        voices = await self.get_voices()
        
        for voice in voices:
            if voice.name.lower() == name.lower():
                return voice
        
        return None
    
    async def get_user_info(self) -> Dict[str, Any]:
        """
        Get user information and quota status.
        
        Returns:
            Dictionary with user info and quota data
            
        Raises:
            ElevenLabsError: If API request fails
        """
        await self._ensure_session()
        
        url = f"{self.BASE_URL}/user"
        
        try:
            async with self.session.get(url) as response:
                await self._handle_response_errors(response)
                return await response.json()
                
        except aiohttp.ClientError as e:
            logger.error(f"Failed to get user info: {e}")
            raise ElevenLabsError(f"Failed to get user info: {e}")
    
    async def _handle_response_errors(self, response: aiohttp.ClientResponse):
        """Handle HTTP response errors."""
        if response.status == 200:
            return
        
        try:
            error_data = await response.json()
            error_message = error_data.get("detail", {}).get("message", "Unknown error")
        except (json.JSONDecodeError, KeyError):
            error_message = f"HTTP {response.status}: {response.reason}"
        
        if response.status == 401:
            raise ElevenLabsError(f"Authentication failed: {error_message}")
        elif response.status == 404:
            raise VoiceNotFoundError(f"Voice not found: {error_message}")
        elif response.status == 429:
            raise APIQuotaError(f"API quota exceeded: {error_message}")
        elif response.status >= 500:
            raise ElevenLabsError(f"Server error: {error_message}")
        else:
            raise ElevenLabsError(f"API error {response.status}: {error_message}")


# Utility functions for common operations
async def create_client(api_key: str) -> ElevenLabsClient:
    """Create and initialize ElevenLabs client."""
    client = ElevenLabsClient(api_key)
    await client._ensure_session()
    return client


async def quick_synthesis(
    api_key: str,
    text: str,
    voice_name: str = "Rachel",
    emotion: str = "neutral"
) -> bytes:
    """
    Quick synthesis function for simple use cases.
    
    Args:
        api_key: ElevenLabs API key
        text: Text to synthesize
        voice_name: Name of voice to use
        emotion: Emotion preset to apply
        
    Returns:
        Audio data as bytes
    """
    async with ElevenLabsClient(api_key) as client:
        voice = await client.get_voice_by_name(voice_name)
        if not voice:
            raise VoiceNotFoundError(f"Voice '{voice_name}' not found")
        
        voice_settings = VoiceSettings.from_emotion(emotion)
        
        return await client.generate_speech(
            text=text,
            voice_id=voice.voice_id,
            voice_settings=voice_settings
        )