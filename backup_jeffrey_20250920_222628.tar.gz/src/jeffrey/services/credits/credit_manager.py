"""
Credit management system for the AI orchestrator.
"""
import logging
from core.config import Config

logger = logging.getLogger("credit_manager")

class CreditManager:
    """
    Manages credits for AI operations, including reserving and consuming credits.
    """
    
    def __init__(self, initial_credits=None):
        """
        Initialize the credit manager with a starting balance.
        
        Args:
            initial_credits (int, optional): Initial credit balance. 
                                           Defaults to Config.DEFAULT_INITIAL_CREDITS.
        """
        self.balance = initial_credits or Config.DEFAULT_INITIAL_CREDITS
        self.reserved = 0
        logger.info("Credit Manager initialized with %d credits", self.balance)
    
    def get_balance(self):
        """
        Get the current available credit balance.
        
        Returns:
            int: The available credit balance
        """
        return self.balance
    
    def reserve_credits(self, amount):
        """
        Reserve credits for an operation.
        
        Args:
            amount (int): Number of credits to reserve
            
        Returns:
            bool: True if reservation successful, False otherwise
        """
        if amount <= 0:
            logger.warning("Invalid credit reservation amount: %d", amount)
            return False
            
        if self.balance < amount:
            logger.warning("Insufficient credits: %d < %d", self.balance, amount)
            return False
            
        self.balance -= amount
        self.reserved += amount
        logger.info("Reserved %d credits. Balance: %d, Reserved: %d", 
                   amount, self.balance, self.reserved)
        return True
    
    def confirm_usage(self, amount):
        """
        Confirm the usage of reserved credits.
        
        Args:
            amount (int): Number of reserved credits to confirm using
            
        Returns:
            bool: True if confirmation successful, False otherwise
        """
        if amount <= 0 or amount > self.reserved:
            logger.warning("Invalid credit confirmation: %d (reserved: %d)", 
                          amount, self.reserved)
            return False
            
        self.reserved -= amount
        logger.info("Confirmed usage of %d credits. Reserved: %d", amount, self.reserved)
        return True
    
    def cancel_reservation(self, amount):
        """
        Cancel a credit reservation and return credits to the balance.
        
        Args:
            amount (int): Number of reserved credits to return
            
        Returns:
            bool: True if cancellation successful, False otherwise
        """
        if amount <= 0 or amount > self.reserved:
            logger.warning("Invalid credit cancellation: %d (reserved: %d)", 
                          amount, self.reserved)
            return False
            
        self.balance += amount
        self.reserved -= amount
        logger.info("Cancelled reservation of %d credits. Balance: %d, Reserved: %d", 
                   amount, self.balance, self.reserved)
        return True