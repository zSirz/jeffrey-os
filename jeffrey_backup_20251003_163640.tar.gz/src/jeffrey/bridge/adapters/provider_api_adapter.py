"""
Provider API Adapter for Jeffrey OS

Handles generic API calls to various providers with:
- Configurable rate limiting per provider
- Response caching
- Authentication handling
- Error handling and retries
"""

from __future__ import annotations

from typing import Any, Dict, Optional

from shared.utils.logger import logger

from ..base import CacheConfig, HTTPAdapter, RateLimitConfig


class ProviderAPIAdapter:
    """Adapter for generic provider API calls"""

    # Default rate limits for known providers
    PROVIDER_RATE_LIMITS = {
        "openai": RateLimitConfig(requests_per_second=1.0, burst_size=5),
        "anthropic": RateLimitConfig(requests_per_second=1.0, burst_size=5),
        "google": RateLimitConfig(requests_per_second=2.0, burst_size=10),
        "default": RateLimitConfig(requests_per_second=10.0, burst_size=20),
    }

    def __init__(
        self,
        provider_name: str = "default",
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        rate_limit: Optional[RateLimitConfig] = None,
        cache_config: Optional[CacheConfig] = None,
    ):
        """
        Initialize provider API adapter

        Args:
            provider_name: Name of the provider for rate limiting
            api_key: API key for authentication
            base_url: Base URL for the provider API
            rate_limit: Custom rate limit config
            cache_config: Custom cache configuration
        """
        self.provider_name = provider_name
        self.api_key = api_key

        # Use provider-specific or custom rate limit
        if rate_limit is None:
            rate_limit = self.PROVIDER_RATE_LIMITS.get(
                provider_name.lower(), self.PROVIDER_RATE_LIMITS["default"]
            )

        # Default cache config if not provided
        if cache_config is None:
            cache_config = CacheConfig(
                enabled=True, ttl_seconds=60, max_size=500  # 1 minute for API responses
            )

        self.http = HTTPAdapter(
            base_url=base_url or "",
            rate_limit=rate_limit,
            cache=cache_config,
            timeout=30,
            max_retries=3,
        )

    async def __aenter__(self):
        """Async context manager entry"""
        await self.http.start()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit"""
        await self.http.close()

    def _prepare_headers(self, headers: Optional[Dict[str, str]] = None) -> Dict[str, str]:
        """
        Prepare headers with authentication

        Args:
            headers: Additional headers to include

        Returns:
            Complete headers dict
        """
        final_headers = headers or {}

        # Add API key if available
        if self.api_key:
            # Common authentication header patterns
            if self.provider_name.lower() == "openai":
                final_headers["Authorization"] = f"Bearer {self.api_key}"
            elif self.provider_name.lower() == "anthropic":
                final_headers["x-api-key"] = self.api_key
            else:
                # Generic authorization header
                final_headers["Authorization"] = f"Bearer {self.api_key}"

        return final_headers

    async def call_api(
        self,
        endpoint: str,
        method: str = "POST",
        headers: Optional[Dict[str, str]] = None,
        params: Optional[Dict[str, Any]] = None,
        json_data: Optional[Dict[str, Any]] = None,
        data: Optional[Any] = None,
        use_cache: bool = True,
        **kwargs,
    ) -> Optional[Dict[str, Any]]:
        """
        Make API call to provider

        Args:
            endpoint: API endpoint (relative or absolute URL)
            method: HTTP method
            headers: Additional headers
            params: Query parameters
            json_data: JSON body data
            data: Raw body data
            use_cache: Whether to use caching
            **kwargs: Additional arguments for the request

        Returns:
            Response data or None if error
        """
        try:
            # Prepare headers with authentication
            final_headers = self._prepare_headers(headers)

            logger.info(f"Calling {self.provider_name} API: {method} {endpoint}")

            response = await self.http.request(
                method=method,
                endpoint=endpoint,
                headers=final_headers,
                params=params,
                json=json_data,
                data=data,
                use_cache=use_cache,
                **kwargs,
            )

            if isinstance(response, dict):
                logger.debug(f"API call successful for {self.provider_name}")
                return response
            else:
                logger.warning(f"Non-JSON response from {self.provider_name}: {type(response)}")
                return {"data": response}

        except Exception as e:
            logger.error(f"API call failed for {self.provider_name}: {e}")
            return None

    async def post(
        self, endpoint: str, json_data: Optional[Dict[str, Any]] = None, **kwargs
    ) -> Optional[Dict[str, Any]]:
        """Convenience method for POST requests"""
        return await self.call_api(endpoint=endpoint, method="POST", json_data=json_data, **kwargs)

    async def get(
        self, endpoint: str, params: Optional[Dict[str, Any]] = None, **kwargs
    ) -> Optional[Dict[str, Any]]:
        """Convenience method for GET requests"""
        return await self.call_api(endpoint=endpoint, method="GET", params=params, **kwargs)

    async def stream_response(
        self, endpoint: str, json_data: Optional[Dict[str, Any]] = None, **kwargs
    ):
        """
        Stream response from API (for SSE/streaming endpoints)

        Args:
            endpoint: API endpoint
            json_data: Request body
            **kwargs: Additional arguments

        Yields:
            Response chunks
        """
        # For streaming, we need direct access to the session
        # This is a simplified version - full implementation would handle SSE parsing
        headers = self._prepare_headers(kwargs.get("headers"))

        async with self.http._session.post(
            self.http._build_url(endpoint), json=json_data, headers=headers
        ) as response:
            response.raise_for_status()

            async for chunk in response.content.iter_any():
                if chunk:
                    yield chunk
