"""
Weather API Adapter for Jeffrey OS

Handles weather data fetching through OpenWeatherMap API with:
- Rate limiting (60 calls/minute for free tier)
- Response caching (5 minutes by default)
- Error handling and retries
"""

from __future__ import annotations

from typing import Any, Dict, Optional

from shared.utils.logger import logger

from ..base import CacheConfig, HTTPAdapter, RateLimitConfig


class WeatherAdapter:
    """Adapter for OpenWeatherMap API calls"""

    def __init__(self, api_key: str) -> None:
        """
        Initialize weather adapter

        Args:
            api_key: OpenWeatherMap API key
        """
        self.api_key = api_key

        # OpenWeatherMap free tier: 60 calls/minute
        rate_limit = RateLimitConfig(requests_per_second=1.0, burst_size=5)  # 60/minute = 1/second

        # Cache weather data for 5 minutes
        cache = CacheConfig(enabled=True, ttl_seconds=300, max_size=100)

        self.http = HTTPAdapter(
            base_url="https://api.openweathermap.org/data/2.5",
            rate_limit=rate_limit,
            cache=cache,
            timeout=10,
        )

    async def __aenter__(self):
        """Async context manager entry"""
        await self.http.start()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit"""
        await self.http.close()

    async def get_weather(
        self, location: str, lang: str = "fr", units: str = "metric"
    ) -> Optional[Dict[str, Any]]:
        """
        Get weather data for a location

        Args:
            location: City name or coordinates
            lang: Language code (default: fr)
            units: Temperature units (metric/imperial/kelvin)

        Returns:
            Weather data dict or None if error
        """
        try:
            params = {"q": location, "appid": self.api_key, "lang": lang, "units": units}

            response = await self.http.get("/weather", params=params)

            if isinstance(response, dict):
                logger.info(f"Weather data retrieved for {location}")
                return response
            else:
                logger.error(f"Unexpected response type: {type(response)}")
                return None

        except Exception as e:
            logger.error(f"Failed to get weather for {location}: {e}")
            return None

    async def get_forecast(
        self, location: str, lang: str = "fr", units: str = "metric", cnt: int = 5
    ) -> Optional[Dict[str, Any]]:
        """
        Get weather forecast for a location

        Args:
            location: City name or coordinates
            lang: Language code (default: fr)
            units: Temperature units (metric/imperial/kelvin)
            cnt: Number of forecast entries (default: 5)

        Returns:
            Forecast data dict or None if error
        """
        try:
            params = {
                "q": location,
                "appid": self.api_key,
                "lang": lang,
                "units": units,
                "cnt": cnt,
            }

            response = await self.http.get("/forecast", params=params)

            if isinstance(response, dict):
                logger.info(f"Forecast data retrieved for {location}")
                return response
            else:
                logger.error(f"Unexpected response type: {type(response)}")
                return None

        except Exception as e:
            logger.error(f"Failed to get forecast for {location}: {e}")
            return None

    async def get_current_conditions(self, location: str) -> Optional[str]:
        """
        Get human-readable current weather conditions

        Args:
            location: City name

        Returns:
            Weather description string or None
        """
        weather_data = await self.get_weather(location)

        if not weather_data:
            return None

        try:
            description = weather_data["weather"][0]["description"]
            temp = weather_data["main"]["temp"]
            feels_like = weather_data["main"]["feels_like"]
            humidity = weather_data["main"]["humidity"]

            return (
                f"À {location}, il fait {temp}°C (ressenti {feels_like}°C) "
                f"avec {description}. Humidité: {humidity}%"
            )

        except KeyError as e:
            logger.error(f"Missing weather data field: {e}")
            return None
