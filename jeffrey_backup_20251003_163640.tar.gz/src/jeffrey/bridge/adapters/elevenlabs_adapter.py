"""
ElevenLabs API Adapter for Jeffrey OS

Handles ElevenLabs TTS API calls with:
- Rate limiting (based on subscription tier)
- Voice caching
- Streaming support
- Error handling
"""

from __future__ import annotations

from collections.abc import AsyncGenerator
from typing import Any, Dict, List, Optional

from shared.utils.logger import logger

from ..base import CacheConfig, HTTPAdapter, RateLimitConfig


class ElevenLabsAdapter:
    """Adapter for ElevenLabs Text-to-Speech API"""

    # ElevenLabs API endpoints
    BASE_URL = "https://api.elevenlabs.io/v1"

    # Rate limits by subscription tier
    RATE_LIMITS = {
        "free": RateLimitConfig(requests_per_second=0.5, burst_size=2),  # 2 req/5s
        "starter": RateLimitConfig(requests_per_second=2.0, burst_size=10),  # Conservative
        "creator": RateLimitConfig(requests_per_second=5.0, burst_size=20),  # Conservative
        "pro": RateLimitConfig(requests_per_second=10.0, burst_size=50),  # Conservative
    }

    def __init__(self, api_key: str, subscription_tier: str = "free", timeout: int = 60):
        """
        Initialize ElevenLabs adapter

        Args:
            api_key: ElevenLabs API key
            subscription_tier: Subscription tier for rate limiting
            timeout: Request timeout in seconds
        """
        self.api_key = api_key
        self.subscription_tier = subscription_tier

        # Get rate limit for tier
        rate_limit = self.RATE_LIMITS.get(subscription_tier.lower(), self.RATE_LIMITS["free"])

        # Cache config - cache voice list for 1 hour
        cache = CacheConfig(enabled=True, ttl_seconds=3600, max_size=100)  # 1 hour for voice list

        self.http = HTTPAdapter(
            base_url=self.BASE_URL, rate_limit=rate_limit, cache=cache, timeout=timeout
        )

        # Cache for voices
        self._voices_cache: Optional[List[Dict[str, Any]]] = None

    async def __aenter__(self):
        """Async context manager entry"""
        await self.http.start()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit"""
        await self.http.close()

    def _get_headers(self) -> Dict[str, str]:
        """Get API headers with authentication"""
        return {"xi-api-key": self.api_key, "Content-Type": "application/json"}

    async def check_api_availability(self) -> bool:
        """
        Check if ElevenLabs API is available

        Returns:
            True if API is accessible
        """
        try:
            response = await self.http.get(
                "/voices",
                headers=self._get_headers(),
                use_cache=False,  # Don't cache availability checks
            )
            return isinstance(response, dict) and "voices" in response

        except Exception as e:
            logger.error(f"ElevenLabs API availability check failed: {e}")
            return False

    async def get_voices(self, force_refresh: bool = False) -> List[Dict[str, Any]]:
        """
        Get available voices

        Args:
            force_refresh: Force refresh from API instead of cache

        Returns:
            List of voice dictionaries
        """
        try:
            response = await self.http.get(
                "/voices", headers=self._get_headers(), use_cache=not force_refresh
            )

            if isinstance(response, dict) and "voices" in response:
                voices = response["voices"]
                self._voices_cache = voices
                logger.info(f"Retrieved {len(voices)} voices from ElevenLabs")
                return voices
            else:
                logger.error(f"Invalid voices response: {response}")
                return []

        except Exception as e:
            logger.error(f"Failed to get voices: {e}")
            return self._voices_cache or []

    async def get_voice_by_name(self, name: str) -> Optional[Dict[str, Any]]:
        """
        Get voice details by name

        Args:
            name: Voice name

        Returns:
            Voice dictionary or None
        """
        voices = await self.get_voices()

        for voice in voices:
            if voice.get("name", "").lower() == name.lower():
                return voice

        return None

    async def text_to_speech(
        self,
        text: str,
        voice_id: str,
        model_id: str = "eleven_multilingual_v2",
        voice_settings: Optional[Dict[str, float]] = None,
        output_format: str = "mp3_44100_128",
    ) -> Optional[bytes]:
        """
        Convert text to speech

        Args:
            text: Text to synthesize
            voice_id: ElevenLabs voice ID
            model_id: Model to use
            voice_settings: Voice settings (stability, similarity_boost, etc.)
            output_format: Audio format

        Returns:
            Audio data as bytes or None if error
        """
        try:
            # Default voice settings
            if voice_settings is None:
                voice_settings = {
                    "stability": 0.5,
                    "similarity_boost": 0.8,
                    "style": 0.0,
                    "use_speaker_boost": True,
                }

            payload = {
                "text": text,
                "model_id": model_id,
                "voice_settings": voice_settings,
                "output_format": output_format,
            }

            response = await self.http.post(
                f"/text-to-speech/{voice_id}",
                json=payload,
                headers=self._get_headers(),
                use_cache=False,  # Never cache TTS responses
            )

            if isinstance(response, bytes):
                logger.info(f"Generated {len(response)} bytes of audio")
                return response
            else:
                logger.error(f"Unexpected TTS response type: {type(response)}")
                return None

        except Exception as e:
            logger.error(f"Text-to-speech failed: {e}")
            return None

    async def text_to_speech_stream(
        self,
        text: str,
        voice_id: str,
        model_id: str = "eleven_multilingual_v2",
        voice_settings: Optional[Dict[str, float]] = None,
        chunk_size: int = 1024,
    ) -> AsyncGenerator[bytes, None]:
        """
        Stream text-to-speech response

        Args:
            text: Text to synthesize
            voice_id: ElevenLabs voice ID
            model_id: Model to use
            voice_settings: Voice settings
            chunk_size: Size of audio chunks to yield

        Yields:
            Audio data chunks
        """
        # Default voice settings
        if voice_settings is None:
            voice_settings = {
                "stability": 0.5,
                "similarity_boost": 0.8,
                "style": 0.0,
                "use_speaker_boost": True,
            }

        payload = {"text": text, "model_id": model_id, "voice_settings": voice_settings}

        headers = self._get_headers()

        # For streaming, we need direct access to the session
        async with self.http._session.post(
            self.http._build_url(f"/text-to-speech/{voice_id}/stream"),
            json=payload,
            headers=headers,
        ) as response:
            response.raise_for_status()

            async for chunk in response.content.iter_chunked(chunk_size):
                if chunk:
                    yield chunk

    async def get_user_info(self) -> Optional[Dict[str, Any]]:
        """
        Get user subscription info

        Returns:
            User info dict or None
        """
        try:
            response = await self.http.get("/user", headers=self._get_headers(), use_cache=True)

            if isinstance(response, dict):
                logger.info(f"Retrieved user info for: {response.get('email', 'unknown')}")
                return response
            else:
                return None

        except Exception as e:
            logger.error(f"Failed to get user info: {e}")
            return None

    async def get_subscription_info(self) -> Optional[Dict[str, Any]]:
        """
        Get detailed subscription information

        Returns:
            Subscription info including character limits
        """
        user_info = await self.get_user_info()

        if not user_info:
            return None

        return user_info.get("subscription", {})
