"""
Package UI pour l'Orchestrateur IA Jeffrey.
Contient les éléments d'interface utilisateur et le système de guidance.
"""