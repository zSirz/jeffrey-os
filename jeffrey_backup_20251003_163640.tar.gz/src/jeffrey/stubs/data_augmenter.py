class DataAugmenter:
    def augment(self, *args, **kwargs):
        return {}
