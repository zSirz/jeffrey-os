class DreamState:
    def __init__(self):
        self.state = "idle"
