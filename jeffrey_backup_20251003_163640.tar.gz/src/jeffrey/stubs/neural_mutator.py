class NeuralMutator:
    def mutate(self, *args, **kwargs):
        return {"mutations": [], "stats": {}}
