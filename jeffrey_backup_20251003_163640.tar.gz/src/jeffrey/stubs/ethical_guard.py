class EthicalGuard:
    def validate(self, *args, **kwargs):
        return True
